import { Card } from "@/components/ui/card"

const stats = [
  { percentage: "94.1%", label: "Felt fully supported and safe in the space" },
  { percentage: "82.4%", label: "Would recommend to friends and others" },
  { percentage: "96.3%", label: "Found sessions effective" },
]

const reviews = [
  {
    name: "AJ / 25F",
    text: "My therapist totally gets me that's all I would say! She provides me with her POV which expands my bandwidth and helps me understand more.",
    rating: 5,
  },
  {
    name: "SG / 26M",
    text: "It's great, very safe space to open up and discuss all the concerns.",
    rating: 5,
  },
  {
    name: "AA / 21F",
    text: "It has definitely helped more than I ever expected. She is easy to talk to and created a much needed safe space for me. She always speaks calmly and in a soft tone which is very comforting.",
    rating: 5,
  },
  {
    name: "JB / 24F",
    text: "The therapist created such a safe and supportive space. And the non-judgemental approach has made it easier for me to open up and explore things. The whole process helped me develop coping strategies and better understanding of things i have struggled with for a long time. I'm grateful for your presence and professionalism, and I look forward to continuing our work together.",
    rating: 5,
  },
]

export function Reviews() {
  return (
    <section id="reviews" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-5xl md:text-6xl font-serif font-bold mb-6 text-balance">Client experiences</h2>
          <p className="text-xl text-muted-foreground">Feedback from those who've done the work</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="p-8 border-2 text-center">
              <div className="text-4xl md:text-5xl font-bold mb-4 text-orange">{stat.percentage}</div>
              <p className="text-lg leading-relaxed text-muted-foreground">{stat.label}</p>
            </Card>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {reviews.map((review, index) => (
            <Card key={index} className="p-8 border-2">
              <p className="text-lg mb-4 leading-relaxed text-pretty">"{review.text}"</p>
              <p className="font-semibold text-foreground">— {review.name}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
