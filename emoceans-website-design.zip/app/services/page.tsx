export default function ServicesPage() {
  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 lg:px-8 py-16">
        <h1 className="text-6xl font-serif font-bold mb-6">Services</h1>
        <p className="text-xl text-muted-foreground">
          Detailed services page coming soon. Visit the home page to see an overview of services.
        </p>
      </div>
    </div>
  )
}
